const client = require('prom-client');
const collectDefaultMetrics = client.collectDefaultMetrics;

// Initialize default metrics
collectDefaultMetrics({
    prefix: 'realtime_data_',
    timeout: 5000
});

// Custom metrics
const httpRequestDuration = new client.Histogram({
    name: 'http_request_duration_seconds',
    help: 'Duration of HTTP requests in seconds',
    labelNames: ['method', 'route', 'status_code']
});

const kafkaMessageCounter = new client.Counter({
    name: 'kafka_messages_total',
    help: 'Total number of Kafka messages processed',
    labelNames: ['topic', 'status']
});

const cassandraQueryDuration = new client.Histogram({
    name: 'cassandra_query_duration_seconds',
    help: 'Duration of Cassandra queries in seconds',
    labelNames: ['operation']
});

const socketConnections = new client.Gauge({
    name: 'socket_connections_total',
    help: 'Total number of active Socket.IO connections'
});

module.exports = {
    client,
    httpRequestDuration,
    kafkaMessageCounter,
    cassandraQueryDuration,
    socketConnections
}; 