const { Kafka } = require('kafkajs');

const kafkaConfig = {
    clientId: 'real-time-data-system',
    brokers: process.env.KAFKA_BROKERS.split(','),
    ssl: false,
    sasl: undefined
};

const kafka = new Kafka(kafkaConfig);

module.exports = {
    kafka,
    TOPICS: {
        DATA_UPDATES: 'data-updates',
        NOTIFICATIONS: 'notifications'
    }
}; 