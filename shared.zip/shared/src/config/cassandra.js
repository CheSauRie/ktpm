const cassandra = require('cassandra-driver');

const cassandraConfig = {
    contactPoints: process.env.CASSANDRA_HOSTS.split(','),
    localDataCenter: 'datacenter1',
    keyspace: 'realtime_data',
    queryOptions: {
        consistency: cassandra.types.consistencies.one,
        prepare: true
    }
};

const client = new cassandra.Client(cassandraConfig);

// Initialize keyspace and tables
const initCassandra = async () => {
    try {
        // Create keyspace if not exists
        await client.execute(`
            CREATE KEYSPACE IF NOT EXISTS realtime_data
            WITH replication = {
                'class': 'SimpleStrategy',
                'replication_factor': 1
            }
        `);

        // Create table if not exists
        await client.execute(`
            CREATE TABLE IF NOT EXISTS realtime_data.key_value_store (
                key text PRIMARY KEY,
                value text,
                updated_at timestamp
            )
        `);

        console.log('Cassandra initialized successfully');
    } catch (error) {
        console.error('Error initializing Cassandra:', error);
        throw error;
    }
};

module.exports = {
    client,
    initCassandra
}; 